/*4. Crie uma função que recebe por parâmetro o tempo de duração de
uma fábrica expressa em segundos e retorna esse tempo em horas,
minutos e segundos.

Ex:
Entrada: 3672
Saída: 1:1:12 */

function fabrica(tempo) {
    let horas = tempo / 3600;
    let minutos = (tempo % 3600) / 60;
    let segundosRestantes = tempo % 60;
  
    return (
      horas.toFixed(0) + ":" + minutos.toFixed(0) + ":" + segundosRestantes.toFixed(0));
  }
  console.log(fabrica(3672));
  