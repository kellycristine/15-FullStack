/* */
function numero(inteiro) {
    if (inteiro % 2 == 0) {
      return false;
    } else {
      return true;
    }
  }
  console.log(numero(6));