//4. Crie duas variáveis. Na primeira coloque um total de minutos e defina um valor para ela (por exemplo, minutos = 120). Na segunda coloque o total em segundos destes minutos armazenados na primeira variável. Apresente no documento html a seguinte informação: "_ minutos equivale à _ segundos!"

var totalDeMinutos = 160;
var totalDeSegundos = totalDeMinutos * 60;

document.write('<h2>' + totalDeMinutos + ' minutos equivale à ' + totalDeSegundos + ' segundos!</h2>');
