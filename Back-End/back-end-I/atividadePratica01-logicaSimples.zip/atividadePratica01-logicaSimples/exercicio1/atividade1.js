//1. Crie uma variável JavaScript e coloque nela o valor de sua idade. Mostre no html usando o document.write() o dado contido na variável junto da frase "Minha idade é x anos", sendo "x" o valor armazenado na sua variável.

var minhaIdade = 34;
document.write('<h2>Minha idade é: ' + minhaIdade + ' anos</h2>');