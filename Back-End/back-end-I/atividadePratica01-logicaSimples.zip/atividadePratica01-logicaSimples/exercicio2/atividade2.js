//2. Crie três variáveis JavaScript, em duas delas atribua os valores que você quiser e na outra atribua o valor da soma das duas primeiras variáveis. Apresente valor da soma no documento html junto da frase "A resultado da soma de x e y é z", sendo x o valor armazenado na primeira variável, y o valor armazenado segunda variável e z o valor armazenado na terceira variável

var valor1 = 10;
var valor2 = 9
var valor3 = valor1 + valor2;

document.write('<h2>O resultado da soma de ' + valor1 + ' e ' + valor2 + ' é ' + valor3 + '. </h2>');