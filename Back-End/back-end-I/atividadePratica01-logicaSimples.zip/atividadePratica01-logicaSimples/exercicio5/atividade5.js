//5. Crie cinco variáveis. Na primeira armazene o nome de um aluno. Na segunda, terceira e quarta coloque 3 notas (valores de 0 à 10). Calcule a média das notas e armazene na quinta variável criada. Apresente no documento html a seguinte informação: "O aluno _____ ficou com média _,_"

var nomeAluno = kelly;
var nota1 = 10;
var nota2 = 9;
var nota3 = 10;
var calculoMedia = nota1 + nota2 + nota3;

document.write('<h2> O aluno ' + nomeAluno + ' ficou com média ' + calculoMedia + '</h2>');
