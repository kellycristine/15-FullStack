var nota1;
nota1 = 10;
var nota2;
nota2 = 10;
var nota3;
nota3 = 0;

var media;
media = (nota1 * 2 + nota2 * 3 + nota3 * 5) / (2 + 3 + 5);
if (media >= 7) {
  console.log("Aprovado");
} else  {
  console.log("Reprovado ");
}

console.log("A média é " + media);