var nome = "Thiago";

var idadeEmAnos = nome;
var idadeEmMeses = idadeEmAnos * 12;
var idadeEmDias = idadeEmAnos * 365;

console.log("A idade de " + nome + " em anos é " + idadeEmDias);
