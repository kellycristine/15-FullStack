if (true) {
  console.log('Valor existe')
  console.log('Valor existe')
  console.log('Valor existe')
  console.log('Valor existe')
  console.log('Valor existe')
  console.log('Valor existe')
  if(false) {
    console.log('Valor existe dentro do outro bloco')
  }
}

console.log('Valor existe fora do bloco')

console.log('IF COMPLEXO')

if (1 !== 1 === 1 === 1) {
  console.log('Valor existe')
} else {
  console.log('Valor não existe na finaleira')
}