let verdadeiroOuFalso = true;
console.log(verdadeiroOuFalso);
console.log(!verdadeiroOuFalso);
console.log(verdadeiroOuFalso);
console.log(!!verdadeiroOuFalso);
