console.log("inicio");
let contador = 0;
while (contador < 10 && contador !== 2) {
  // 2 < 10 && 2!== 2
  // true && false
  console.log("dentro do while");
  contador += 1;
}
console.log("fim");
