// const NOME;
// const NOME = VALOR;
// if (VALOR) {

// };
// var teste = false
// while (teste) {
//   teste = true
// }
// for (const teste = 1; teste  11; teste++) {

// }

// 1 + 1;

// for (const NOME of VALOR) {

// }

// for (let i =0; i < 5; i++) {
//   const item = VALOR[i];
// }

for (const item of ["test", "test2"]) {
  console.log(item);
}

// NOME
// VALOR
// ESTATICO
// 5
// true
// []

// VARIAVEL
// NOME

// POR UM ARRAY
// VALOR[VALOR]
// ENDERECO[NUMERO]

// POR UM OBJETO
// VALOR.NOME

// POR UMA FUNCAO
// VALOR()
