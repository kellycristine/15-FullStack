const soma = function (numero1, numero2) {
  return numero1 + numero2;
};

const resultado1 = soma(1, 2);

const resultado2 = soma(2, 3) + undefined();

console.log(resultado1, resultado2);
