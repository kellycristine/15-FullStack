const arrayDeObjetos = [
  {
    nome: "thiago",
  },
  {
    nome: "teste",
  },
];

//VALOR.NOME
//ENDERECO.NOME

const retornoForeach = arrayDeObjetos.filter(function (valor) {
  return 0;
});
console.log("retornoForeach", retornoForeach === );
console.log("fim");
