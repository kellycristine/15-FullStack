// SINTEXE DE EXECUCAO DA FUNCAO
// VALOR(VALOR1, VALOR2....)
// ENDERECO_DA_FUCAO()
console.log("inicio");
function nome(teste, nomevariave, nomevariavel2) {
  console.log(teste);
  console.log(nomevariave);
  console.log(nomevariavel2);
  console.log("dentro da funcao");
  return 5;
}
const array = [nome];
nome = 2;
const viajei = function () {};

console.log(function () {});

// nome(1, 2 + 2, []);
console.log("array");
console.log(array[]);
array[]();
// nome();

console.log("fim");
