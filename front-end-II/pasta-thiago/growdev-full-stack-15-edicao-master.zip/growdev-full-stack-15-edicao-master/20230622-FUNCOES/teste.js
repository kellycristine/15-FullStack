console.log("inicio");

function banana(numero1, numero) {
  console.log("dentro da funcao");
  return console.log(numero1, numero);
}
const soma = 1 + 2;
const teste = banana(1, 3);
console.log(banana(1, 3));
