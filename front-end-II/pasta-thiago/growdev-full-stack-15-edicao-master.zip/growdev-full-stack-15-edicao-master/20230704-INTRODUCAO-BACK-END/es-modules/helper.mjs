console.log("helper.mjs");
export function somar(a, b) {
  return a + b;
}

export default somar;
