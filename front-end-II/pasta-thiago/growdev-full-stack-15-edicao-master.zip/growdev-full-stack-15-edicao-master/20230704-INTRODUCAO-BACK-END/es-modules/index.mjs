import ahahahhahaha, { teste, teste2 } from "./teste.mjs";
import somar from "./helper.mjs";
console.log("Inicio index");
console.log(somar(1, 2));
console.log(teste, teste2);
