import somar from "./helper.mjs";
console.log("teste.mjs");
const teste = "lkkkkk";

export var teste2 = "ahahaha";
export let teste3 = "teste3";

export default somar(3, 7);
