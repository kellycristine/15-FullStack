import { teste } from "./teste.js";

teste();
