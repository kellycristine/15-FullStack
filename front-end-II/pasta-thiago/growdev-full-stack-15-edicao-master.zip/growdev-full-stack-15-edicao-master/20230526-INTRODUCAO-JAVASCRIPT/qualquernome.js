var teste;
teste = 1;
console.log(teste);

var replica;
replica = teste;
console.log(replica);

console.log("mudei o valor da gaveta teste");
teste = "novo valor";

console.log(teste);
console.log(replica);
