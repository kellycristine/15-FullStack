const numeros = [];
console.log(numeros.length);
numeros[0] = 1;
console.log(numeros.length);
console.log(numeros);
//VALOR.NOME SINTAXE
//ENDERECO.NOME
