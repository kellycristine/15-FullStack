const numeros = [2, 7, 5, 3];
let soma = 0;
for (const itemAtual of numeros) {
  const itemAtual = numeros[indice];
  console.log("O item é igual a: " + itemAtual);
  soma += itemAtual;
}

console.log("A soma é: " + soma);
