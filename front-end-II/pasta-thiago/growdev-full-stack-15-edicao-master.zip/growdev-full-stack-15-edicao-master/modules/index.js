import { soma, subtracao } from "./utils.js";
import express from "express";
console.log(express);
console.log("aqui dentro do index.mjs");
console.log(soma(1, 2));
console.log(subtracao(1, 2));
