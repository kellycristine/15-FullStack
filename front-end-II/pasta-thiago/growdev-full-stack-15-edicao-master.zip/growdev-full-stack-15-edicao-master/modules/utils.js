export function soma(valor, valor2) {
  return valor + valor2;
}
export function subtracao(valor, valor2) {
  return valor - valor2;
}
console.log("aqui dentro do utils.mjs");
