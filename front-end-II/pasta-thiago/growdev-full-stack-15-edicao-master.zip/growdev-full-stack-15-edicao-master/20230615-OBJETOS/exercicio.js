const listaAlunos = [];

listaAlunos[0] = {
  nome: "Ândria",
  presenca1: true,
  presenca2: false,
};

listaAlunos[0].presenca2 = true;

console.log(listaAlunos);
