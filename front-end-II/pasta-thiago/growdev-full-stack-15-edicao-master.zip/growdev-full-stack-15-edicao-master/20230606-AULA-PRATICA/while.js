console.log("INICIO");
let nome;
while (nome) {
  nome = prompt("Digite seu nome:");
  console.log(nome);
}
console.log("fim");
