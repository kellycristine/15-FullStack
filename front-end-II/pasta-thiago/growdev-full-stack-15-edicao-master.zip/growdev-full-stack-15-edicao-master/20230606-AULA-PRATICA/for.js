console.log("for.js");
var vezesParaExecutar = parseInt(
  prompt("Digite quantas vezes o for deve executar:")
);
for (var teste = 0; teste <= vezesParaExecutar; teste += 1) {
  console.log("executou");
}
console.log("fim do for");
