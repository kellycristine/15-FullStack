/*
1. Criar um array e percorrê-lo utilizando o loop for
a. Crie um array com o nome "nomes" e adicione 4 nomes de
pessoas que você conhece
b. Utilize o loop for para percorrer o array e exibir os nomes na
tela
*/
const nomes = ['Jaque', 'Maria', 'João', 'José'];

for (let index = 0; index < nomes.length; index++) {
    const element = nomes[index];
    console.log(element);
    
}