/*1. Crie um objeto em JavaScript para colocar dois atributos de um
produto. Atribua o preço e descrição do produto com o valor “90” e a
descrição com o valor “Mouse”. Mostre no console o valor dos dois
atributos.*/

let produtos = {
    descricao: 'mouse',
    preco: 90
};
console.log(`produtoé um ${produto.descricao} e o preco é ${produto.preco}`);""