import express from "express";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(cors());

app.get("/", (req, res) => {
  console.log(req.query.page);
  /** O ARRAY A SER PAGINADO */
  const array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
  /** QUANTIDADE DE ITEMS POR PAGINA */
  const itemsPorPagina = 3;
  /** PAGINA QUE QUERO RETORNAR */
  const pagina = req.query.page || 1;

  const indiceInicial = (pagina - 1) * itemsPorPagina;
  const indiceFinal = pagina * itemsPorPagina - 1;

  /** LISTA SOMENTE COM OS ITEMS DAQUELA PAGINA */
  const arrayPaginado = array.slice(indiceInicial, indiceFinal + 1);

  const resposta = {
    mensagem: "Tudo Certo. Toma aqui o array.",
    total: Math.ceil(array.length / itemsPorPagina),
    data: arrayPaginado,
  };

  res.json(resposta).sendStatus(200);
});

app.post("/cadastro", (req, res) => {
  const dadosRecebidos = req.body;
  console.log(req.body);
  res.sendStatus(200);
});

app.listen(3001, () => console.log("api rodando na porta 3001"));
